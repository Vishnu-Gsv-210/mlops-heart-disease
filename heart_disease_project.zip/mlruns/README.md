# MLflow runs

## Tracking store

This project uses a **SQLite tracking store**: `mlflow.db` at the repository
root. This MLflow version refuses a bare `file:` store for a backend, so all
run parameters, metrics, and tags live in that single SQLite file. The `mlruns/`
directory holds the run **artifacts** (serialized models, classification
reports, plots) laid out as `mlruns/<experiment_id>/<run_id>/artifacts/...`.

Both paths are wired in `src/heart_disease/config.py`
(`MLFLOW_DB_URI`, `MLFLOW_ARTIFACT_ROOT`) and used automatically by
`python -m src.heart_disease.train`.

## Launch the UI

From the repository root:

```bash
.venv/bin/mlflow ui --backend-store-uri sqlite:///mlflow.db --default-artifact-root ./mlruns
```

Then open http://127.0.0.1:5000 .

If port 5000 is taken (macOS AirPlay Receiver binds it), use another port:

```bash
.venv/bin/mlflow ui --backend-store-uri sqlite:///mlflow.db --default-artifact-root ./mlruns --port 5001
```

## Notes

- Current experiment history includes 7 runs, including 2 deliberately retained
  failed runs from real debugging — they are honest evidence, not noise to scrub.
- To reset tracking, delete `mlflow.db` and retrain; `mlruns/` artifacts for
  deleted runs can be pruned alongside it. Do not delete `mlflow.db` if you
  need the run history as assignment evidence.
- Copying the project: ship `mlflow.db` **and** `mlruns/` together, or the UI
  will show runs without their artifacts.
